Directory to publish alignment results.
