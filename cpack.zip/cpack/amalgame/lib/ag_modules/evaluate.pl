:- module(eval_analyzer,
	  []).

%:- use_module(library(semweb/rdf_db)).
%:- use_module(library(semweb/rdf_label)).
%:- use_module(library(amalgame/vocabulary)).

:- use_module(library(amalgame/expand_graph)).

:- public amalgame_module/1.

% todo 
% amalgame_module(amalgame:'Evaluater').
