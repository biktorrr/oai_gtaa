:- module(amalgame_hooks_loader, []).

:- use_module(autocomplete).
:- use_module(strategy_backward_compatability).
:- use_module(skos_browser).
