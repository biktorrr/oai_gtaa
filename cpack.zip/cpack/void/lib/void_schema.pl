:- module(void_schema, []).
:- use_module(library(semweb/rdf_db)).
:- use_module(library(semweb/rdf_library)).

/** <module> Provide VoID schema and namespace

This module provides the VoID schema and the prefix =void= for use in
Prolog.
*/

:- rdf_register_ns(void, 'http://rdfs.org/ns/void#').
:- rdf_attach_library(void(rdf)).
:- rdf_load_library(void).
