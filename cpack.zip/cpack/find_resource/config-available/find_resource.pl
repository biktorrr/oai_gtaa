:- module(conf_find_resource, []).

/** <module> Library to find RDF resources by a textual query
*/

:- use_module(library(find_resource)).