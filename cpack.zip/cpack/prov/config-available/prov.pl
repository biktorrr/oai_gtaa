:- module(conf_prov, []).

/** <module> Schema and viz. supporting the W3C PROV vocabulary
*/

:- use_module(library(prov_schema)).
